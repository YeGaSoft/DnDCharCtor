self.assetsManifest = {
  "version": "2peur3xG",
  "assets": [
    {
      "hash": "sha256-QqyhLxaEAJnCsPzT+v2MR+ipVo/3K/fjbNvC74HHllE=",
      "url": "DnDCharCtor.Pwa.styles.css"
    },
    {
      "hash": "sha256-0g6T2/p76/r6nZTEb2ngQYrg+hcG+ioXER4aUUhP10s=",
      "url": "_content/DnDCharCtor.Ui/DnDCharCtor.Ui.mip08aoij2.bundle.scp.css"
    },
    {
      "hash": "sha256-CrCNdUVy1LAqE4iOQW3xrOkOx5Rv6ZNgUo72ICF6YEE=",
      "url": "_content/DnDCharCtor.Ui/addOpacityToBackground.js"
    },
    {
      "hash": "sha256-SNBGasuCdeqOLwzChOiFI7arwMkv7MK0+72ez0n/18w=",
      "url": "_content/DnDCharCtor.Ui/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "_content/DnDCharCtor.Ui/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "_content/DnDCharCtor.Ui/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "_content/DnDCharCtor.Ui/favicon.png"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-em7H1x6ijv/Ln1xS18rdjLu1JRbd3KqLfbEg9v+9Ot8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-YXK/HpBHSdAvYKGx6FxD4KNnfqJyfeRndjuw0HB6lAM=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-Ev4Kojt6pIRpgo1en7WTdMnGAI6m6iD4kfsPNHe5dzE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-PP/sd+/TmUOGcOlWecN29U8NiuDIEWAdn05aDunSL8Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-3+jF/yOfwYyQhLujhQlSrvp3NBll+oEUF7v13pin53A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-2bhET+uXWbAao2aJyUqqscx9PObMTXmpUAkDQOQBGI8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-nIU5FWzn1UKAWh1+g35w3aDIn8pSmnmQV1YWZ+1eb8w=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-C/YKywsVlWaSpZ1PLDeRKkkkM6ki2G2gT9ny+WVuERA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-5Xro3i41QLeYkA4vXMC3sJ/GOerzbXq4CJRFnA+jYNE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-EnvcMggAdstebmtcZrEOhDW5p/e0dFj2ZywJtuMypIw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-s8i9htPaAt7ZBCd4Nd0wqrNPZB5+37bPZH72pf5wd9o=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.dwk6czdzfo.bundle.scp.css"
    },
    {
      "hash": "sha256-/LPTy2KpNBBYdj9b6lNMDILfmbdqo+FWKCFS6WQd0mU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-4SNdvLM7SDhaju7Ir+uYFq6/+6PwZqn7sQPCIe+nI0g=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-kX+9ky61TMxar94Z7+S8myontpvgH4571DVehjxVvM4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-jvdEwbPP9ySWwm0cTSiOqdIfO15rtDmoxKmiqmFQR/A=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js"
    },
    {
      "hash": "sha256-y7L+XtwoUJtcUnvXGeRLVrLj2uLMTgPyNKJlEJnFbpc=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js.map"
    },
    {
      "hash": "sha256-pCIEjwDATOwa31+YvucoW1WTxT4YiQVDFhw94hu6wx8=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js"
    },
    {
      "hash": "sha256-MTgEQwaemErPPoFSvy9/AvhoR7QaOAVkSgXh+Gs5jmY=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js.map"
    },
    {
      "hash": "sha256-la7lyIF2RfLmzbgQq451BnkJEU/wykMPE6pCn8Po4pI=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js"
    },
    {
      "hash": "sha256-HQWKRYNJ6U0CQ6cjuHiZNYzn9EyBxinvWwT2zctFdWE=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js.map"
    },
    {
      "hash": "sha256-xfIDskQRT1esRY72kCfq1uRsHDQZ4EfpM4HsMMw3JkA=",
      "url": "_framework/CommunityToolkit.Mvvm.zue8oahq20.wasm"
    },
    {
      "hash": "sha256-9bIWnKxlUNFFV+O+XzsZF4+1HqNTsDaGSBYWjaiuMeg=",
      "url": "_framework/DnDCharCtor.Common.typ6akt8y5.wasm"
    },
    {
      "hash": "sha256-BDNBdopM3t8x7rmOkz3sMyKz3bUyeEHirQvP1kmtc5g=",
      "url": "_framework/DnDCharCtor.Models.smlilc9ur7.wasm"
    },
    {
      "hash": "sha256-CD7BhAmrjO3GJlwU/zPOyPzQN5Yj6Pqn08rA0kW4Ujo=",
      "url": "_framework/DnDCharCtor.Pwa.0a5pj610fu.wasm"
    },
    {
      "hash": "sha256-wEIXxhMf6fkQfrUWacZ55f4aiYUmQh6zncUqHFUB6Hg=",
      "url": "_framework/DnDCharCtor.Resources.shse36431m.wasm"
    },
    {
      "hash": "sha256-sbWIP0B+GuT8d+RsRvl6Zi/1WExc/DmtrXiD7F1UL9U=",
      "url": "_framework/DnDCharCtor.Ui.nqhqeocqvy.wasm"
    },
    {
      "hash": "sha256-bs6jWDLM7aG8H+Us2Pi76qTuXZVX2GTJ/dHiYnjnrYY=",
      "url": "_framework/DnDCharCtor.Validation.y42n3d5x34.wasm"
    },
    {
      "hash": "sha256-Uc8LC8qGjKRARH5nWWOI2+Ao6znkqDcz+p0BCHZBwek=",
      "url": "_framework/DnDCharCtor.ViewModels.9auk1i1nly.wasm"
    },
    {
      "hash": "sha256-QKAZqrlkfl1cRc/6/yKfq6Nny7gwd5BnPjEw/RI07Uc=",
      "url": "_framework/Microsoft.AspNetCore.Components.4740n9936h.wasm"
    },
    {
      "hash": "sha256-IXiV3hUWdWahlCYOkyZBXPptYn0zdrl/kjgxcN5IeP0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.nqe1r7xgeq.wasm"
    },
    {
      "hash": "sha256-06CYtHDbDJFC7Wpg+3zpzVx5AF+xLb3FR5d8NPyOchk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.r6axjfm46g.wasm"
    },
    {
      "hash": "sha256-tenyrtDDAQkBr7rtJZ+5KFxEGmteUuQb1RVDF7w6CKc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.tuea0ctohw.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-UUgfZrqOAC6508DrIal9n7jmpJ1UzPD9XGP9LOUa/dg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bpiof5ac41.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-Sut6zwJxe8UqofuAS1eDF9eZFoR5mjFDInY5N91R+Z4=",
      "url": "_framework/Microsoft.Extensions.Localization.2y8sbx0rdg.wasm"
    },
    {
      "hash": "sha256-aS0ITScQIlXxUIfeGneYL7Sehcj+PoHM3H+ulDIVpJM=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ztavmx9kuz.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-X6nbPDr/svb7AWc/9nJ+PJvo8M7ULNX3y2x2hc2sxXo=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.9ytw3dkm3v.wasm"
    },
    {
      "hash": "sha256-zRPgvUtRauLs9LddjREkF3heeNb3yaqirhsXBi0kGQ8=",
      "url": "_framework/Microsoft.Extensions.Options.nbtz5iwb4h.wasm"
    },
    {
      "hash": "sha256-vPhp59NjtqbOjFelQNr7ShU1Vj0MrSUpnS6H7Qv6BhM=",
      "url": "_framework/Microsoft.Extensions.Primitives.ory5sfp8mt.wasm"
    },
    {
      "hash": "sha256-TzgOmKuLLA6nSA/vBk6hMuiKaYvaeo8sidfJOho07oA=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.5zcoch04zb.wasm"
    },
    {
      "hash": "sha256-0FocjmE53Hhf78FK+sKqC5PBhCrochhBhjI6OABvDS4=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Icons.gw0x4hns00.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-O0wpPYq9gJfj+soaCLsGfDPSwIGSNuODjgTWFEH/Raw=",
      "url": "_framework/Microsoft.JSInterop.hprq5chrbe.wasm"
    },
    {
      "hash": "sha256-Dm7c9mzF/+a8adF5F3z1VVB558hJSJBWvB0ksgtnB1A=",
      "url": "_framework/Prism.2o16cmmx8u.wasm"
    },
    {
      "hash": "sha256-HTF2GMDzfdHG6JsIwKAF8i7CHiRRDA3B8Gq4Z2pQykk=",
      "url": "_framework/Prism.Container.Abstractions.nvrbxbm9ft.wasm"
    },
    {
      "hash": "sha256-QaPcMOvhhMlpvyhQPdzif9bTs2RbQ+FsuD+7egdQhlU=",
      "url": "_framework/Prism.Events.t14vxj1qdk.wasm"
    },
    {
      "hash": "sha256-GSdgCGHC17oFwhbDjnqZcnuGnNyTmm9AmURqiGHclD8=",
      "url": "_framework/SkiaSharp.1illbvshlc.wasm"
    },
    {
      "hash": "sha256-eV3F6NH5/nfLcQMQAloe6sGD4/VtH983nxzPYykRU30=",
      "url": "_framework/SkiaSharp.Views.Blazor.74nar1fiep.wasm"
    },
    {
      "hash": "sha256-o6cRFrxOFhtmO/OJTEY/raeZwwMWTjS7MZmZGv6u0Sw=",
      "url": "_framework/System.Collections.Concurrent.rmve47lfgl.wasm"
    },
    {
      "hash": "sha256-3Wqmx3Ley9sbWvdf9vNjBr7MR6l/moKF0XlkS6zRggk=",
      "url": "_framework/System.Collections.Immutable.1n2qvb971e.wasm"
    },
    {
      "hash": "sha256-Rt983cJ29RtxD05bwpWgVSyxesh9nGUMpLifksrk+Zo=",
      "url": "_framework/System.Collections.NonGeneric.ipje0hy292.wasm"
    },
    {
      "hash": "sha256-O07OV5IRptzHnOhxKlUaqhRdPrOFEw0lfSHvsn+wz7I=",
      "url": "_framework/System.Collections.Specialized.hdmqukthmj.wasm"
    },
    {
      "hash": "sha256-UkHgGJMzviXnBRmOErpgbyfmPmHvSzyi1gNhTSQJius=",
      "url": "_framework/System.Collections.if41aiywrv.wasm"
    },
    {
      "hash": "sha256-yFElDTKm4sOVBZGcnAhK/vely6Sg066vJUXRMnOMZIs=",
      "url": "_framework/System.ComponentModel.Annotations.o4xiaj8pu2.wasm"
    },
    {
      "hash": "sha256-0vxn3EAET5Z9nzEw7hPwIg7nmBACcRoky9smBLnY7G4=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.au94u5ibr2.wasm"
    },
    {
      "hash": "sha256-L2+bQdHjUsWcbTOZRRvzyNl9m+uvsvlyqjewbc0uRKM=",
      "url": "_framework/System.ComponentModel.Primitives.lzhfo4yf20.wasm"
    },
    {
      "hash": "sha256-4FV0pLiyN6w0WW613kaYMYfZuu4f6kAEab7DKFItFNI=",
      "url": "_framework/System.ComponentModel.TypeConverter.c1jityqu7f.wasm"
    },
    {
      "hash": "sha256-QWVyYfFMyQkEJcXzgiXaAF6HzJbM9vtnP9Ds9H24kU8=",
      "url": "_framework/System.ComponentModel.tpqwi9wclf.wasm"
    },
    {
      "hash": "sha256-Ac19dncwSS5LH0Ll4fM4NNmHvq4hJNTKOI7mj8b+wHU=",
      "url": "_framework/System.Console.xkdtj8hrcg.wasm"
    },
    {
      "hash": "sha256-icw6qyF6hER8PaVOVG9Jg0X7Cz0gKMAOnE66fy7fzxM=",
      "url": "_framework/System.Drawing.Primitives.h6uv2c3w8p.wasm"
    },
    {
      "hash": "sha256-WVsuqJc4HlfGX2IAj2A4hyBr8PlHSuOntwo6r8xxdtM=",
      "url": "_framework/System.Drawing.fqblu2hlpm.wasm"
    },
    {
      "hash": "sha256-A/zbBw0DrouhwRThvr8F1IcKa5ApGW5BE01HoHB7igA=",
      "url": "_framework/System.IO.Pipelines.twix2pm6u4.wasm"
    },
    {
      "hash": "sha256-x0zT2aSLYWK0kfLMjmU/Ag7X52XvJiHePjwaR/ggzi0=",
      "url": "_framework/System.Linq.Expressions.xmc1pd3q1o.wasm"
    },
    {
      "hash": "sha256-FaHPKcoL2+P40TuYXaWnxwxeMK0JV9EYMX5uFobuccw=",
      "url": "_framework/System.Linq.bos7ic99ue.wasm"
    },
    {
      "hash": "sha256-ELv1WOW2IxWs5ZJi58aQy3wvEg4rsf9HjqSH90jTz30=",
      "url": "_framework/System.Memory.ww9v9ea3r3.wasm"
    },
    {
      "hash": "sha256-DD73DIECIdjHNDQjfDF/DnQBAZ7UT128am2WWEpUB4w=",
      "url": "_framework/System.Net.Http.4sg4k4vifm.wasm"
    },
    {
      "hash": "sha256-a4dB30YFNq/SY/LiMHqwVY80wc9IhWkxSr0potvkLog=",
      "url": "_framework/System.Net.Primitives.p74tuosjpr.wasm"
    },
    {
      "hash": "sha256-XLI6nuPCyoVppg8QezxDtvTIWshD5o+KoBZ3jZnYxpA=",
      "url": "_framework/System.ObjectModel.0zjx377gir.wasm"
    },
    {
      "hash": "sha256-5BMUcaQ2jpay9DKJH8H8CNMyvSc5CxXUPBke496PDYU=",
      "url": "_framework/System.Private.CoreLib.42tkcw18w5.wasm"
    },
    {
      "hash": "sha256-OsoNN/9p1G0G1iOKMh951+5wAwJYL64Wvbh62Ejx7Z4=",
      "url": "_framework/System.Private.Uri.akqv28ds8x.wasm"
    },
    {
      "hash": "sha256-EM1sujwkmzYQhLQlGSTpBA4VosDf6WVJ4+RuDjMdbI8=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.8i0iyuy1vf.wasm"
    },
    {
      "hash": "sha256-Lo6I94ZPG9MpcgWgVSTb6QDrGMgktO8soMZeL8zfrTE=",
      "url": "_framework/System.Runtime.att1x43b1l.wasm"
    },
    {
      "hash": "sha256-2iawAcamkbvdFlRLtNLEoRnPv0gvF1i1QTceWH12XS0=",
      "url": "_framework/System.Text.Encodings.Web.y1u40ejdcx.wasm"
    },
    {
      "hash": "sha256-xWbrAbjgRbnBiW7bGvGMDtrNpP8lM2ICfVHO+zOtrNQ=",
      "url": "_framework/System.Text.Json.ro85q5x163.wasm"
    },
    {
      "hash": "sha256-zc9PRqjEQPGMUvnARMKB3DYbG5Y0WCzoIchdQfaUmAU=",
      "url": "_framework/System.Text.RegularExpressions.zko3pi5geg.wasm"
    },
    {
      "hash": "sha256-Yoity8mUJ/0bAijvHNd7zbcULudbqvX9l0lx6y+gvls=",
      "url": "_framework/System.Threading.6jb0qty5zt.wasm"
    },
    {
      "hash": "sha256-nW4R1VXEFpJurxBxOOQmmMkHVzVjJMLPcMeSUh+FiOM=",
      "url": "_framework/System.Threading.Thread.l2wp4b7ge2.wasm"
    },
    {
      "hash": "sha256-JTFuCK158shXIWK3NjdzwK5OZag1jcRJzsH8H5Gd6OA=",
      "url": "_framework/System.pndwwxah3a.wasm"
    },
    {
      "hash": "sha256-4LncAZflXT8D3uSgVfFrDTLNLwIWqb+Z7uJ78zkH6M0=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-4fcq8tkthe8NCyglexBQeFe46f8pVnZqh/nKJRPB0Bk=",
      "url": "_framework/de-DE/DnDCharCtor.Resources.resources.hw9fk55gvn.wasm"
    },
    {
      "hash": "sha256-lIFBSyH5fOmCyz9NzfVceXU09qRLS0mn0JZG0tuYWBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-PGhaAKtjnFvuMp8YerA7IG6XV/zq1VTu9ND+/JremOc=",
      "url": "_framework/dotnet.native.cyvgyc8wuh.wasm"
    },
    {
      "hash": "sha256-3ff0CRp3Wc30NydzS7ELQvZSp3mO3tWq0830GRjJrHU=",
      "url": "_framework/dotnet.native.jc2x6yni9j.js"
    },
    {
      "hash": "sha256-gypqZnsxxUh4y4EJmawvOCaX4hoTaesVGwIgWXwZcNw=",
      "url": "_framework/dotnet.runtime.rubq0v1yiy.js"
    },
    {
      "hash": "sha256-gu0eZ0x9ECWX1y7v2n41AQLui8OHqHPLCv3iLB798BQ=",
      "url": "_framework/en-US/DnDCharCtor.Resources.resources.qh0oa46bif.wasm"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "app.css"
    },
    {
      "hash": "sha256-v0pKqT5E7IJJsaUQ1S2ay4s+/i9T4hssD5AH0SVItCg=",
      "url": "getBrowserLanguage.js"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-M09mo6ZtqbaMnIh0xLjaF9EDU8F9lK+slB9+MA+L/Ys=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ODUvSraqkI0cxNfc2AR9TydMBXPmULI+cBWpThWgoi0=",
      "url": "manifest.webmanifest"
    }
  ]
};
