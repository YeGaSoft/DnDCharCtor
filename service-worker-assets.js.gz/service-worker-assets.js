self.assetsManifest = {
  "version": "WQW2vOs7",
  "assets": [
    {
      "hash": "sha256-QqyhLxaEAJnCsPzT+v2MR+ipVo/3K/fjbNvC74HHllE=",
      "url": "DnDCharCtor.Pwa.styles.css"
    },
    {
      "hash": "sha256-0g6T2/p76/r6nZTEb2ngQYrg+hcG+ioXER4aUUhP10s=",
      "url": "_content/DnDCharCtor.Ui/DnDCharCtor.Ui.mip08aoij2.bundle.scp.css"
    },
    {
      "hash": "sha256-SNBGasuCdeqOLwzChOiFI7arwMkv7MK0+72ez0n/18w=",
      "url": "_content/DnDCharCtor.Ui/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "_content/DnDCharCtor.Ui/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "_content/DnDCharCtor.Ui/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "_content/DnDCharCtor.Ui/favicon.png"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-em7H1x6ijv/Ln1xS18rdjLu1JRbd3KqLfbEg9v+9Ot8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-YXK/HpBHSdAvYKGx6FxD4KNnfqJyfeRndjuw0HB6lAM=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-Ev4Kojt6pIRpgo1en7WTdMnGAI6m6iD4kfsPNHe5dzE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-PP/sd+/TmUOGcOlWecN29U8NiuDIEWAdn05aDunSL8Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-3+jF/yOfwYyQhLujhQlSrvp3NBll+oEUF7v13pin53A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-2bhET+uXWbAao2aJyUqqscx9PObMTXmpUAkDQOQBGI8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-nIU5FWzn1UKAWh1+g35w3aDIn8pSmnmQV1YWZ+1eb8w=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-C/YKywsVlWaSpZ1PLDeRKkkkM6ki2G2gT9ny+WVuERA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-5Xro3i41QLeYkA4vXMC3sJ/GOerzbXq4CJRFnA+jYNE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-EnvcMggAdstebmtcZrEOhDW5p/e0dFj2ZywJtuMypIw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-s8i9htPaAt7ZBCd4Nd0wqrNPZB5+37bPZH72pf5wd9o=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.dwk6czdzfo.bundle.scp.css"
    },
    {
      "hash": "sha256-/LPTy2KpNBBYdj9b6lNMDILfmbdqo+FWKCFS6WQd0mU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-4SNdvLM7SDhaju7Ir+uYFq6/+6PwZqn7sQPCIe+nI0g=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-kX+9ky61TMxar94Z7+S8myontpvgH4571DVehjxVvM4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-q7hg+xatRwLx94rnn/0xPeXpQ6SotKJt3f8KRk99CLY=",
      "url": "_framework/CommunityToolkit.Mvvm.tmycpt0frw.wasm"
    },
    {
      "hash": "sha256-Bz1HwcgcZwZQu6a3345YGokps98a7gRhKiJUTPzJHGs=",
      "url": "_framework/DnDCharCtor.Common.n8do8fc24d.wasm"
    },
    {
      "hash": "sha256-YH17vh5rhd5wcsMlM9SRouEIA6DAdq8+NUL0iphLFJk=",
      "url": "_framework/DnDCharCtor.Models.sxy2oa6eq7.wasm"
    },
    {
      "hash": "sha256-J8w9dissLQfxlnmACNyWvlRbRXgXDozeA4rPGikkIwU=",
      "url": "_framework/DnDCharCtor.Pwa.xekmb6idoe.wasm"
    },
    {
      "hash": "sha256-7L2m8qGfS1/T+G3Ou9LwHa9sMzCTfn1VNzKuY/Tq0xc=",
      "url": "_framework/DnDCharCtor.Resources.0l6j6t0xfe.wasm"
    },
    {
      "hash": "sha256-wXdqnln+qdDhUfhFv9BlhGWwMnxcYkSDbQKfdKb61T8=",
      "url": "_framework/DnDCharCtor.Ui.vgeccenj3m.wasm"
    },
    {
      "hash": "sha256-uWkRXBWXCFMju20i6m3n/zzzO8ROzmHn2vZ7Chxecsw=",
      "url": "_framework/DnDCharCtor.Validation.djoqr4esy3.wasm"
    },
    {
      "hash": "sha256-pGt+BA0UwW8lwvzXb5jaRwk58dS4gipDhbOKmKnsF4U=",
      "url": "_framework/DnDCharCtor.ViewModels.s2403932kx.wasm"
    },
    {
      "hash": "sha256-IXiV3hUWdWahlCYOkyZBXPptYn0zdrl/kjgxcN5IeP0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.nqe1r7xgeq.wasm"
    },
    {
      "hash": "sha256-VolU+TCdjv6e9Xx+jau3oe7FfVnSlYBM0q+vjELkpEs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.65btlxc6j8.wasm"
    },
    {
      "hash": "sha256-pu76rHZnWXnD8OJbsfHeWNtvNYwvUMrsao8y79n+GXY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.mhi741p0i5.wasm"
    },
    {
      "hash": "sha256-dIU0a62b5JqjtfYAVA1jfmq2CwkvEFdkYu7CxtWkjlk=",
      "url": "_framework/Microsoft.AspNetCore.Components.g3lnwg9jui.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-UUgfZrqOAC6508DrIal9n7jmpJ1UzPD9XGP9LOUa/dg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bpiof5ac41.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-Sut6zwJxe8UqofuAS1eDF9eZFoR5mjFDInY5N91R+Z4=",
      "url": "_framework/Microsoft.Extensions.Localization.2y8sbx0rdg.wasm"
    },
    {
      "hash": "sha256-aS0ITScQIlXxUIfeGneYL7Sehcj+PoHM3H+ulDIVpJM=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ztavmx9kuz.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-X6nbPDr/svb7AWc/9nJ+PJvo8M7ULNX3y2x2hc2sxXo=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.9ytw3dkm3v.wasm"
    },
    {
      "hash": "sha256-zRPgvUtRauLs9LddjREkF3heeNb3yaqirhsXBi0kGQ8=",
      "url": "_framework/Microsoft.Extensions.Options.nbtz5iwb4h.wasm"
    },
    {
      "hash": "sha256-vPhp59NjtqbOjFelQNr7ShU1Vj0MrSUpnS6H7Qv6BhM=",
      "url": "_framework/Microsoft.Extensions.Primitives.ory5sfp8mt.wasm"
    },
    {
      "hash": "sha256-ih/eSnScwBj4BJNklz5NPZ/231wru7HqkXn931jtB4Y=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Icons.uqjudl4p7a.wasm"
    },
    {
      "hash": "sha256-Z/RJXw7QhT6GhIJ29/mxQ7m2AT0sLm5D5t2jGXiAt48=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.lp4b3rvs4b.wasm"
    },
    {
      "hash": "sha256-lNqP2ot1f2PhPr/5ZgFueuYFhUgz/pVAaqmi0u4H8Lo=",
      "url": "_framework/Microsoft.JSInterop.426305nhc4.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-Dm7c9mzF/+a8adF5F3z1VVB558hJSJBWvB0ksgtnB1A=",
      "url": "_framework/Prism.2o16cmmx8u.wasm"
    },
    {
      "hash": "sha256-HTF2GMDzfdHG6JsIwKAF8i7CHiRRDA3B8Gq4Z2pQykk=",
      "url": "_framework/Prism.Container.Abstractions.nvrbxbm9ft.wasm"
    },
    {
      "hash": "sha256-QaPcMOvhhMlpvyhQPdzif9bTs2RbQ+FsuD+7egdQhlU=",
      "url": "_framework/Prism.Events.t14vxj1qdk.wasm"
    },
    {
      "hash": "sha256-nmhUPBjB8ZbEN0U5j2acgnW4fkbSYlov7U3e30Lsp8A=",
      "url": "_framework/System.6bp5k9v1ih.wasm"
    },
    {
      "hash": "sha256-PCdBYDJnu/tKLSaVwkunPKwi/ar8GojSOPy+ZUYAKeU=",
      "url": "_framework/System.Collections.Concurrent.4a1juzduz3.wasm"
    },
    {
      "hash": "sha256-N560dssQo+evs25YvAtY/k1umtrByzHazNULqQDGUSw=",
      "url": "_framework/System.Collections.Immutable.1q6vapuo1c.wasm"
    },
    {
      "hash": "sha256-pNWrDePWfKodlJjxBCpA0AeYDZNBM9z6ukop8vIGGgI=",
      "url": "_framework/System.Collections.NonGeneric.whuhpq856d.wasm"
    },
    {
      "hash": "sha256-wgx6+QIFnCf+Mn0WmQvAfe5ADq29OcyRAtwgaFM1ZNc=",
      "url": "_framework/System.Collections.Specialized.6q98sde5u4.wasm"
    },
    {
      "hash": "sha256-nSDA+Yg66jTkDzQxEsi+/ctlR+WDVhng0GUrRid4Qho=",
      "url": "_framework/System.Collections.vlprdijx71.wasm"
    },
    {
      "hash": "sha256-pj/n25JeDOI7eGtpZ74u9EEMnCKm3MuoRTN0heeHuOU=",
      "url": "_framework/System.ComponentModel.Annotations.aj3rlo2dr2.wasm"
    },
    {
      "hash": "sha256-KTUbd2XRzZkj1HdIu4BfL6uuMZoK/H8cF4y0COC9b+8=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.p83vjok25w.wasm"
    },
    {
      "hash": "sha256-7FsBGHSFGHWx+rj7CpZ6lGdWabiLLbpN2ao/aI/JvDw=",
      "url": "_framework/System.ComponentModel.Primitives.o3dvw0jcvz.wasm"
    },
    {
      "hash": "sha256-y7L0D8dBzPzDVV3q3eeUJ4nxSNyCopa7yvqbh6FM3g8=",
      "url": "_framework/System.ComponentModel.TypeConverter.xtwoh4h9nh.wasm"
    },
    {
      "hash": "sha256-RYR/h0Ie5rYHB+ej3Knxr+cFNDRJ6It4r6HxoCWHpB4=",
      "url": "_framework/System.ComponentModel.xhkm7nd2fe.wasm"
    },
    {
      "hash": "sha256-bLaPE4siZpi2BMpxYHg+FXVObOesCgKUu0HCOCJQhSE=",
      "url": "_framework/System.Console.kgw56smcu9.wasm"
    },
    {
      "hash": "sha256-PRQRYJA2gCqmG5z0q6ME3ToPLSbSrXynInpQXgHflkU=",
      "url": "_framework/System.Drawing.Primitives.n387vud9wf.wasm"
    },
    {
      "hash": "sha256-jfrV6JGIvYrfs1jCRBurLN4PE8PjmLPf9OxsPnSu+Lw=",
      "url": "_framework/System.Drawing.zse2axizjh.wasm"
    },
    {
      "hash": "sha256-JA6sPl6GA5NH8pNdn7k4E0ophulug+EchR9kvweDkS0=",
      "url": "_framework/System.IO.Pipelines.g5ih8ovpg3.wasm"
    },
    {
      "hash": "sha256-MpkqCXMxAeVrIgp5tMKBY6y6BntajGruj5s5YKAdY2g=",
      "url": "_framework/System.Linq.Expressions.et92zaxio1.wasm"
    },
    {
      "hash": "sha256-4BPwZGCl1u4ggvT5TWGXTqcSwV1U0oxFcinzUxUMod4=",
      "url": "_framework/System.Linq.wo6wq8n1pm.wasm"
    },
    {
      "hash": "sha256-P7mFU11EHTqUHU5vQxkh8XZD8GW2AJmV26vLue6tr5E=",
      "url": "_framework/System.Memory.hwvt8u0jiq.wasm"
    },
    {
      "hash": "sha256-PuONLjVT+RdY6SF7OiLiUWRgrDDy0Yhg/3WsHIKKNh0=",
      "url": "_framework/System.Net.Http.if1wca2g7s.wasm"
    },
    {
      "hash": "sha256-S21BwAjdSlZYujl9gymU48gTnFdfUyHO8N4chrKPCN0=",
      "url": "_framework/System.Net.Primitives.rcgya37loz.wasm"
    },
    {
      "hash": "sha256-kmWlEF5Z4EcmbkCICpvZXzJRm5WRHviLkwTVS7WGF3I=",
      "url": "_framework/System.ObjectModel.2sa0jrbpxd.wasm"
    },
    {
      "hash": "sha256-7sd+W2GAxsJ9Lm4sN2rh0MZC9P5CHlElxRgDNbK9nbQ=",
      "url": "_framework/System.Private.CoreLib.a189rj5f9g.wasm"
    },
    {
      "hash": "sha256-fR8pyI+rhx8AOs1KXadPWJl157SJdCe76YuiUT0DLo4=",
      "url": "_framework/System.Private.Uri.1n8bbxt9re.wasm"
    },
    {
      "hash": "sha256-VS4CSyZJNRAj+SrJqgbXBFWlGMlNDgM4rbwJ6gTH5qg=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.x50649m5t2.wasm"
    },
    {
      "hash": "sha256-S4pGV8Vh4iOFo41//q6fKJiRW4C7A5oT/BXasRBACLk=",
      "url": "_framework/System.Runtime.tipq20fhbp.wasm"
    },
    {
      "hash": "sha256-K0a2+/Q0wj9REnO++W2ZYzEFcZ1KQ3XU4J2ggDQoOiA=",
      "url": "_framework/System.Text.Encodings.Web.7hk6pkd9k5.wasm"
    },
    {
      "hash": "sha256-Z0GCxmYG+vAuF9NZrR2h3bT/GtpmyI540x0N5TBezJk=",
      "url": "_framework/System.Text.Json.fyhyquay58.wasm"
    },
    {
      "hash": "sha256-LP2bAr7Neo5tHYRTyROS4fjbuvr7X8J3XKj/YX9q2rA=",
      "url": "_framework/System.Text.RegularExpressions.4aolnqfelj.wasm"
    },
    {
      "hash": "sha256-SPFxwy+MELRlEW9I5nMvlpwDdHTdKCenY+yjclemsDg=",
      "url": "_framework/System.Threading.Thread.gyvmuupc66.wasm"
    },
    {
      "hash": "sha256-7qrP8PInGOP7PHAQD+l0yPkipKvI1BvS10/MBjojTPg=",
      "url": "_framework/System.Threading.ygvvs2c8w8.wasm"
    },
    {
      "hash": "sha256-oQAdKGmKVjLR/dIi5k9wl0lip3FWyP98tS7Ku/vlkXs=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-YUtwUDo8j0ToxSYtANQHbr1VmKON5OtaRzhCJ276rvA=",
      "url": "_framework/de-DE/DnDCharCtor.Resources.resources.r1an6zn265.wasm"
    },
    {
      "hash": "sha256-GbKWK+esqeL1E24rCVsCvsQCzaJM65aknWOT1UhUYa4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-9oJpFjF0TqJ0olZBjwJ5Xj3IkMyGjohtjbAhiNdFTBs=",
      "url": "_framework/dotnet.native.ann9bewb11.js"
    },
    {
      "hash": "sha256-QQmgCRciZ1fBWZkHhn71LWQJkzSRuX3E6vW94boPCuk=",
      "url": "_framework/dotnet.native.nevjpazyry.wasm"
    },
    {
      "hash": "sha256-uD1t4tsPtmIHsx30SC4OztehGGaHVDksFD38rL2e3P4=",
      "url": "_framework/dotnet.runtime.o8gq1i8bk6.js"
    },
    {
      "hash": "sha256-tJy7dTz3zULEDo446FQZPWZEsZMQbXUVHtDGrZCWEuY=",
      "url": "_framework/en-US/DnDCharCtor.Resources.resources.0zajt6pscr.wasm"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "app.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-+oD/Nb0s/WyoysRWDbPUxbauquYEEK79NZxUTNWRcA4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ODUvSraqkI0cxNfc2AR9TydMBXPmULI+cBWpThWgoi0=",
      "url": "manifest.webmanifest"
    }
  ]
};
