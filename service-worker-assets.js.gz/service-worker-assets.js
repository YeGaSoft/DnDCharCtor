self.assetsManifest = {
  "version": "nxp69kQc",
  "assets": [
    {
      "hash": "sha256-QqyhLxaEAJnCsPzT+v2MR+ipVo/3K/fjbNvC74HHllE=",
      "url": "DnDCharCtor.Pwa.styles.css"
    },
    {
      "hash": "sha256-0g6T2/p76/r6nZTEb2ngQYrg+hcG+ioXER4aUUhP10s=",
      "url": "_content/DnDCharCtor.Ui/DnDCharCtor.Ui.mip08aoij2.bundle.scp.css"
    },
    {
      "hash": "sha256-SNBGasuCdeqOLwzChOiFI7arwMkv7MK0+72ez0n/18w=",
      "url": "_content/DnDCharCtor.Ui/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "_content/DnDCharCtor.Ui/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "_content/DnDCharCtor.Ui/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "_content/DnDCharCtor.Ui/favicon.png"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-em7H1x6ijv/Ln1xS18rdjLu1JRbd3KqLfbEg9v+9Ot8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-YXK/HpBHSdAvYKGx6FxD4KNnfqJyfeRndjuw0HB6lAM=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-Ev4Kojt6pIRpgo1en7WTdMnGAI6m6iD4kfsPNHe5dzE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-PP/sd+/TmUOGcOlWecN29U8NiuDIEWAdn05aDunSL8Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-3+jF/yOfwYyQhLujhQlSrvp3NBll+oEUF7v13pin53A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-2bhET+uXWbAao2aJyUqqscx9PObMTXmpUAkDQOQBGI8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-nIU5FWzn1UKAWh1+g35w3aDIn8pSmnmQV1YWZ+1eb8w=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-C/YKywsVlWaSpZ1PLDeRKkkkM6ki2G2gT9ny+WVuERA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-5Xro3i41QLeYkA4vXMC3sJ/GOerzbXq4CJRFnA+jYNE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-EnvcMggAdstebmtcZrEOhDW5p/e0dFj2ZywJtuMypIw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-s8i9htPaAt7ZBCd4Nd0wqrNPZB5+37bPZH72pf5wd9o=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.dwk6czdzfo.bundle.scp.css"
    },
    {
      "hash": "sha256-/LPTy2KpNBBYdj9b6lNMDILfmbdqo+FWKCFS6WQd0mU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-4SNdvLM7SDhaju7Ir+uYFq6/+6PwZqn7sQPCIe+nI0g=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-kX+9ky61TMxar94Z7+S8myontpvgH4571DVehjxVvM4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-jvdEwbPP9ySWwm0cTSiOqdIfO15rtDmoxKmiqmFQR/A=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js"
    },
    {
      "hash": "sha256-y7L+XtwoUJtcUnvXGeRLVrLj2uLMTgPyNKJlEJnFbpc=",
      "url": "_content/SkiaSharp.Views.Blazor/DpiWatcher.js.map"
    },
    {
      "hash": "sha256-pCIEjwDATOwa31+YvucoW1WTxT4YiQVDFhw94hu6wx8=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js"
    },
    {
      "hash": "sha256-MTgEQwaemErPPoFSvy9/AvhoR7QaOAVkSgXh+Gs5jmY=",
      "url": "_content/SkiaSharp.Views.Blazor/SKHtmlCanvas.js.map"
    },
    {
      "hash": "sha256-la7lyIF2RfLmzbgQq451BnkJEU/wykMPE6pCn8Po4pI=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js"
    },
    {
      "hash": "sha256-HQWKRYNJ6U0CQ6cjuHiZNYzn9EyBxinvWwT2zctFdWE=",
      "url": "_content/SkiaSharp.Views.Blazor/SizeWatcher.js.map"
    },
    {
      "hash": "sha256-q7hg+xatRwLx94rnn/0xPeXpQ6SotKJt3f8KRk99CLY=",
      "url": "_framework/CommunityToolkit.Mvvm.tmycpt0frw.wasm"
    },
    {
      "hash": "sha256-IGUDAtZUptM8NH7IK/g/LPpycfWOfL8tM/p2mk/O0VE=",
      "url": "_framework/DnDCharCtor.Common.ctc9kqklvo.wasm"
    },
    {
      "hash": "sha256-Md+GLyBToUyXPq78mIEGJmBYb6Q3qkOoq8QjUP+XV3M=",
      "url": "_framework/DnDCharCtor.Models.btza5e7ban.wasm"
    },
    {
      "hash": "sha256-RedRp2vC5X/UEcBnp/wofbZ9fIKnyWYUix2B5bq8o7E=",
      "url": "_framework/DnDCharCtor.Pwa.r0i2d14xyg.wasm"
    },
    {
      "hash": "sha256-CpLi81BONAHnDtPZwYsWSAERmgtE5gZnSu/3aVcV0sc=",
      "url": "_framework/DnDCharCtor.Resources.2tmqwqfn80.wasm"
    },
    {
      "hash": "sha256-s12W2SxJwU5Qk5e2+CxK1LQJOCQ7GQrcIcaT9o5CYWI=",
      "url": "_framework/DnDCharCtor.Ui.ftdfun5mlb.wasm"
    },
    {
      "hash": "sha256-S0ytVDebCNKwnxk+9DxsvXGVPTasQLukeadCMx9/S68=",
      "url": "_framework/DnDCharCtor.Validation.930pfmarrp.wasm"
    },
    {
      "hash": "sha256-Lw8mG4skOFQsoJT+B/d9hEuooxBFdwWu2P+20KFbqic=",
      "url": "_framework/DnDCharCtor.ViewModels.r91vvijviz.wasm"
    },
    {
      "hash": "sha256-IXiV3hUWdWahlCYOkyZBXPptYn0zdrl/kjgxcN5IeP0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.nqe1r7xgeq.wasm"
    },
    {
      "hash": "sha256-06CYtHDbDJFC7Wpg+3zpzVx5AF+xLb3FR5d8NPyOchk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.r6axjfm46g.wasm"
    },
    {
      "hash": "sha256-tenyrtDDAQkBr7rtJZ+5KFxEGmteUuQb1RVDF7w6CKc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.tuea0ctohw.wasm"
    },
    {
      "hash": "sha256-dIU0a62b5JqjtfYAVA1jfmq2CwkvEFdkYu7CxtWkjlk=",
      "url": "_framework/Microsoft.AspNetCore.Components.g3lnwg9jui.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-UUgfZrqOAC6508DrIal9n7jmpJ1UzPD9XGP9LOUa/dg=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bpiof5ac41.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-Sut6zwJxe8UqofuAS1eDF9eZFoR5mjFDInY5N91R+Z4=",
      "url": "_framework/Microsoft.Extensions.Localization.2y8sbx0rdg.wasm"
    },
    {
      "hash": "sha256-aS0ITScQIlXxUIfeGneYL7Sehcj+PoHM3H+ulDIVpJM=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ztavmx9kuz.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-X6nbPDr/svb7AWc/9nJ+PJvo8M7ULNX3y2x2hc2sxXo=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.9ytw3dkm3v.wasm"
    },
    {
      "hash": "sha256-zRPgvUtRauLs9LddjREkF3heeNb3yaqirhsXBi0kGQ8=",
      "url": "_framework/Microsoft.Extensions.Options.nbtz5iwb4h.wasm"
    },
    {
      "hash": "sha256-vPhp59NjtqbOjFelQNr7ShU1Vj0MrSUpnS6H7Qv6BhM=",
      "url": "_framework/Microsoft.Extensions.Primitives.ory5sfp8mt.wasm"
    },
    {
      "hash": "sha256-NUfr51Sl0QEDY8v2aeXUMMsLmlj2FVQrVTvoBpMI30U=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.5wbc0wwom0.wasm"
    },
    {
      "hash": "sha256-Ol7F8TMMhlECg9cLlOKyf94A6A4ldojLUDjzNZwC6O4=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Icons.611onjmpph.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-O0wpPYq9gJfj+soaCLsGfDPSwIGSNuODjgTWFEH/Raw=",
      "url": "_framework/Microsoft.JSInterop.hprq5chrbe.wasm"
    },
    {
      "hash": "sha256-Dm7c9mzF/+a8adF5F3z1VVB558hJSJBWvB0ksgtnB1A=",
      "url": "_framework/Prism.2o16cmmx8u.wasm"
    },
    {
      "hash": "sha256-HTF2GMDzfdHG6JsIwKAF8i7CHiRRDA3B8Gq4Z2pQykk=",
      "url": "_framework/Prism.Container.Abstractions.nvrbxbm9ft.wasm"
    },
    {
      "hash": "sha256-QaPcMOvhhMlpvyhQPdzif9bTs2RbQ+FsuD+7egdQhlU=",
      "url": "_framework/Prism.Events.t14vxj1qdk.wasm"
    },
    {
      "hash": "sha256-GSdgCGHC17oFwhbDjnqZcnuGnNyTmm9AmURqiGHclD8=",
      "url": "_framework/SkiaSharp.1illbvshlc.wasm"
    },
    {
      "hash": "sha256-eV3F6NH5/nfLcQMQAloe6sGD4/VtH983nxzPYykRU30=",
      "url": "_framework/SkiaSharp.Views.Blazor.74nar1fiep.wasm"
    },
    {
      "hash": "sha256-nmhUPBjB8ZbEN0U5j2acgnW4fkbSYlov7U3e30Lsp8A=",
      "url": "_framework/System.6bp5k9v1ih.wasm"
    },
    {
      "hash": "sha256-PCdBYDJnu/tKLSaVwkunPKwi/ar8GojSOPy+ZUYAKeU=",
      "url": "_framework/System.Collections.Concurrent.4a1juzduz3.wasm"
    },
    {
      "hash": "sha256-N560dssQo+evs25YvAtY/k1umtrByzHazNULqQDGUSw=",
      "url": "_framework/System.Collections.Immutable.1q6vapuo1c.wasm"
    },
    {
      "hash": "sha256-pNWrDePWfKodlJjxBCpA0AeYDZNBM9z6ukop8vIGGgI=",
      "url": "_framework/System.Collections.NonGeneric.whuhpq856d.wasm"
    },
    {
      "hash": "sha256-wgx6+QIFnCf+Mn0WmQvAfe5ADq29OcyRAtwgaFM1ZNc=",
      "url": "_framework/System.Collections.Specialized.6q98sde5u4.wasm"
    },
    {
      "hash": "sha256-nSDA+Yg66jTkDzQxEsi+/ctlR+WDVhng0GUrRid4Qho=",
      "url": "_framework/System.Collections.vlprdijx71.wasm"
    },
    {
      "hash": "sha256-pj/n25JeDOI7eGtpZ74u9EEMnCKm3MuoRTN0heeHuOU=",
      "url": "_framework/System.ComponentModel.Annotations.aj3rlo2dr2.wasm"
    },
    {
      "hash": "sha256-KTUbd2XRzZkj1HdIu4BfL6uuMZoK/H8cF4y0COC9b+8=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.p83vjok25w.wasm"
    },
    {
      "hash": "sha256-7FsBGHSFGHWx+rj7CpZ6lGdWabiLLbpN2ao/aI/JvDw=",
      "url": "_framework/System.ComponentModel.Primitives.o3dvw0jcvz.wasm"
    },
    {
      "hash": "sha256-y7L0D8dBzPzDVV3q3eeUJ4nxSNyCopa7yvqbh6FM3g8=",
      "url": "_framework/System.ComponentModel.TypeConverter.xtwoh4h9nh.wasm"
    },
    {
      "hash": "sha256-RYR/h0Ie5rYHB+ej3Knxr+cFNDRJ6It4r6HxoCWHpB4=",
      "url": "_framework/System.ComponentModel.xhkm7nd2fe.wasm"
    },
    {
      "hash": "sha256-bLaPE4siZpi2BMpxYHg+FXVObOesCgKUu0HCOCJQhSE=",
      "url": "_framework/System.Console.kgw56smcu9.wasm"
    },
    {
      "hash": "sha256-PRQRYJA2gCqmG5z0q6ME3ToPLSbSrXynInpQXgHflkU=",
      "url": "_framework/System.Drawing.Primitives.n387vud9wf.wasm"
    },
    {
      "hash": "sha256-jfrV6JGIvYrfs1jCRBurLN4PE8PjmLPf9OxsPnSu+Lw=",
      "url": "_framework/System.Drawing.zse2axizjh.wasm"
    },
    {
      "hash": "sha256-JA6sPl6GA5NH8pNdn7k4E0ophulug+EchR9kvweDkS0=",
      "url": "_framework/System.IO.Pipelines.g5ih8ovpg3.wasm"
    },
    {
      "hash": "sha256-MpkqCXMxAeVrIgp5tMKBY6y6BntajGruj5s5YKAdY2g=",
      "url": "_framework/System.Linq.Expressions.et92zaxio1.wasm"
    },
    {
      "hash": "sha256-Ad+hTMQ10mKTGB+9LTZs86UR3W5Nz+PPvKWQS6n2amo=",
      "url": "_framework/System.Linq.fwzh9q4nqu.wasm"
    },
    {
      "hash": "sha256-P7mFU11EHTqUHU5vQxkh8XZD8GW2AJmV26vLue6tr5E=",
      "url": "_framework/System.Memory.hwvt8u0jiq.wasm"
    },
    {
      "hash": "sha256-PuONLjVT+RdY6SF7OiLiUWRgrDDy0Yhg/3WsHIKKNh0=",
      "url": "_framework/System.Net.Http.if1wca2g7s.wasm"
    },
    {
      "hash": "sha256-S21BwAjdSlZYujl9gymU48gTnFdfUyHO8N4chrKPCN0=",
      "url": "_framework/System.Net.Primitives.rcgya37loz.wasm"
    },
    {
      "hash": "sha256-kmWlEF5Z4EcmbkCICpvZXzJRm5WRHviLkwTVS7WGF3I=",
      "url": "_framework/System.ObjectModel.2sa0jrbpxd.wasm"
    },
    {
      "hash": "sha256-2908vdrXh+oPPmQPbE1Hw3XwiowjGNUXLxcra9hP5uw=",
      "url": "_framework/System.Private.CoreLib.rkzf4myvr3.wasm"
    },
    {
      "hash": "sha256-fR8pyI+rhx8AOs1KXadPWJl157SJdCe76YuiUT0DLo4=",
      "url": "_framework/System.Private.Uri.1n8bbxt9re.wasm"
    },
    {
      "hash": "sha256-G/0CoG2QyrjKI3DY3hm5bbXMhot9d62l1j07bENCsN4=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.5khwaumco2.wasm"
    },
    {
      "hash": "sha256-OOao8hrjGZQSYQzOsc/pr5NTQEb0HP3psBHsYkkRUic=",
      "url": "_framework/System.Runtime.oc399pkmfv.wasm"
    },
    {
      "hash": "sha256-K0a2+/Q0wj9REnO++W2ZYzEFcZ1KQ3XU4J2ggDQoOiA=",
      "url": "_framework/System.Text.Encodings.Web.7hk6pkd9k5.wasm"
    },
    {
      "hash": "sha256-Z0GCxmYG+vAuF9NZrR2h3bT/GtpmyI540x0N5TBezJk=",
      "url": "_framework/System.Text.Json.fyhyquay58.wasm"
    },
    {
      "hash": "sha256-LP2bAr7Neo5tHYRTyROS4fjbuvr7X8J3XKj/YX9q2rA=",
      "url": "_framework/System.Text.RegularExpressions.4aolnqfelj.wasm"
    },
    {
      "hash": "sha256-YFofzkCMjMDQJIW1waKFzOXFmIaM66bYRU8XG4GveT0=",
      "url": "_framework/System.Threading.4r1b8shjbu.wasm"
    },
    {
      "hash": "sha256-SPFxwy+MELRlEW9I5nMvlpwDdHTdKCenY+yjclemsDg=",
      "url": "_framework/System.Threading.Thread.gyvmuupc66.wasm"
    },
    {
      "hash": "sha256-jh8yEKtbvuuOs0fp3mKjSMD1DQo+xbHSD+5GVVbbAbw=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-m10xltA3T0FhCeQQJeWtkR0ookggGObQ7UpbaxRicec=",
      "url": "_framework/de-DE/DnDCharCtor.Resources.resources.fvj831cccy.wasm"
    },
    {
      "hash": "sha256-GbKWK+esqeL1E24rCVsCvsQCzaJM65aknWOT1UhUYa4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-5IaIGiNrVed28JY+PeMwhQdvqZEuHF4dL3YPOtD2M8Q=",
      "url": "_framework/dotnet.native.k4sy40syf8.wasm"
    },
    {
      "hash": "sha256-xbZAA4Cjy/S4YZN9nlGhGD8NvzBmJlivW2cWFcCTPXg=",
      "url": "_framework/dotnet.native.v3n1q12kqh.js"
    },
    {
      "hash": "sha256-uD1t4tsPtmIHsx30SC4OztehGGaHVDksFD38rL2e3P4=",
      "url": "_framework/dotnet.runtime.o8gq1i8bk6.js"
    },
    {
      "hash": "sha256-FcikCjpa7HgONNVTXj923zyA9MKGr07PPqMAgxdNNn8=",
      "url": "_framework/en-US/DnDCharCtor.Resources.resources.1twgmerleo.wasm"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "app.css"
    },
    {
      "hash": "sha256-v0pKqT5E7IJJsaUQ1S2ay4s+/i9T4hssD5AH0SVItCg=",
      "url": "getBrowserLanguage.js"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-W+KUL8knH1uqi3zu1vA8zzqq0gyltRn5w0zdlHZsvPI=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ODUvSraqkI0cxNfc2AR9TydMBXPmULI+cBWpThWgoi0=",
      "url": "manifest.webmanifest"
    }
  ]
};
